setwd("C:\\Users\\it24101982\\Desktop\\Lab8")
getwd()



##Importing the data set
data<- read.table("Data - Lab 8.txt",header=TRUE)
fix(data)
attach (data)
##Question 01
#Commands "mean" & "var" will compute the mean and variance for data.
popmn<-mean (Nicotine)
popvar<-var (Nicotine)


##Question 02
#First create null vectors to store sample data sets.
samples<-c()
n<-c()
#The "for" loop will be used to create and assign samples of size 5 for "samples" variable created above. #Using "sample" command we can draw a random sample either with replacement or without replacement. #By making "replace" argument as TRUE we can create samples with replacement.
for (i in 1:30) {
}
s<-sample (Nicotine, 5,replace=TRUE)
samples<-cbind(samples,s)
n<-c(n, paste('S',1))
#Assign column names for each sample created. Names have stored earlier under "n" variable. colnames (samples)=n
#Using "apply" command we can ask to calculate any function such as mean, variance, etc. row wise or #column wise in a matrix.
#Here, considering the second argument as "2" we can calculate either mean/variance column wise #which stored earlier in "samples" variable which is a matrix.
s.means<-apply (samples,2, mean)
s.vars<-apply(samples,2,var)

##Question3
samplemean<-mean(s.means)
samplevars<-(s.means)

##Question4
popmn
samplemean


##Question5
truevar=popvar/5
samplevars
truevar

##Exercise

# Example laptop bag weights data (you should replace this with your actual data)
weights <- c(1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6)

# Calculate population mean and standard deviation
population_mean <- mean(weights)
population_sd <- sd(weights)

# Print the results
cat("Population Mean: ", population_mean, "\n")
cat("Population Standard Deviation: ", population_sd, "\n")


# Set seed for reproducibility
set.seed(123)

# Initialize vectors to store sample means and sample standard deviations
sample_means <- numeric(25)
sample_sds <- numeric(25)

# Draw 25 random samples
for (i in 1:25) {
  sample_data <- sample(weights, size = 6, replace = TRUE)
  sample_means[i] <- mean(sample_data)
  sample_sds[i] <- sd(sample_data)
}

# Print the sample means and sample standard deviations
cat("Sample Means: ", sample_means, "\n")
cat("Sample Standard Deviations: ", sample_sds, "\n")


# Calculate the mean and standard deviation of the 25 sample means
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

# Print the results
cat("Mean of the Sample Means: ", mean_of_sample_means, "\n")
cat("Standard Deviation of the Sample Means: ", sd_of_sample_means, "\n")

# Relationship with the true population parameters
cat("True Population Mean: ", population_mean, "\n")
cat("True Population Standard Deviation: ", population_sd, "\n")

